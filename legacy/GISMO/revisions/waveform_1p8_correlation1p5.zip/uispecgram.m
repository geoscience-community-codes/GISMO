function varargout = uispecgram(varargin)
% UISPECGRAM M-file for uispecgram.fig
%      USAGE: uispecgram(waveform, spectralobject)
%       NOTICE, this is reversed from before.  spectralobject is now
%       optional, as one will be created if it doesn't already exist.
%
%      UISPECGRAM, by itself, creates a new UISPECGRAM or raises the existing
%      singleton*.
%
%      H = UISPECGRAM returns the handle to a new UISPECGRAM or the handle to
%      the existing singleton*.
%
%      UISPECGRAM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UISPECGRAM.M with the given input arguments.
%
%      UISPECGRAM('Property','Value',...) creates a new UISPECGRAM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before uispecgram_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to uispecgram_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% Modified by hand 10/22/2005
%
% Edit the above text to modify the response to help uispecgram

% Last Modified by GUIDE v2.5 09-Jun-2005 15:09:54

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @uispecgram_OpeningFcn, ...
    'gui_OutputFcn',  @uispecgram_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin & ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before uispecgram is made visible.
function uispecgram_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to uispecgram (see VARARGIN)

% Choose default command line output for uispecgram
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


%celso code
ud.w = varargin{1};
if nargin == 2
    ud.s = varargin{2};
else
    ud.s = spectralobject;
end

if isa(ud.w,'spectralobject')
    disp('Please call uispecgram with the waveform first, optional spectralobject second.');
    error('Expected uispecgram(waveform) or uispecgram(waveform, spectralobject)');
end

try
    vnames = getVolcanoList; %retrieves cells of volcano names
catch
    warning('Cannot get full list of volcanoes.  Continuing anyway.');
    vnames = {'UNK'};
end

thisVolcano = 'UNK';
for n=1:length(vnames)
    %    v = vnames{n};
    try
        load(vnames{n}, 'Stations');
    catch
        continue
    end
    StaList = upper({Stations.name});
    sN = find(strcmp(get(ud.w,'station'),StaList));
    if ~isempty(sN)
        thisVolcano = vnames{n};
        break
    end
end
ud.v = thisVolcano % store the volcano name..

set(hObject,'UserData',ud); %spectralobject & waveform


% This sets up the initial plot - only do when we are invisible
% so window can get raised using uispecgram.
if strcmp(get(hObject,'Visible'),'off')
    %set pointer to watch
    %P = getptr(gcf);
    %setptr(gcf,'watch')

    %draw the waveform
    axes(handles.axes_waveform);
    plot(ud.w);
    axis tight

    %draw the spectrogram
    axes(handles.axes_specgram);
    specgram(ud.s,ud.w);
    title('');
    colorbar('horiz');

    %set the parameters to match ouir input parameter...
    dbL = get(ud.s,'dbLims');
    set(handles.minDBLIMS,'value',dbL(1),'sliderstep',[1/200 10/200],'max',200,'min',0);
    set(handles.edit_MIN,'value',dbL(1),'string',num2str(dbL(1)));
    set(handles.maxDBLIMS,'value',dbL(2),'sliderstep',[1/200 10/200],'max',200,'min',0);
    set(handles.edit_MAX,'value',dbL(2),'string',num2str(dbL(2)));
    set(handles.slider_FreqMax,'value',get(ud.s,'freqMax'),'sliderstep',[1/49 10/49],'max',49,'min',1);
    set(handles.edit_FreqMax,'value',get(handles.slider_FreqMax,'value'), 'string', num2str(get(handles.slider_FreqMax,'value')));
    switch get(ud.s,'NFFT')
        case 256, v = 7;
        case 512, v = 6;
        case 1024, v = 5;
        case 2048, v = 4;
        case 4096, v = 3;
        case 8192, v = 2;
        case 16384, v = 1;
        otherwise
            v = 8; %custom
    end
    set(handles.popupmenu_NFFT,'value',v);

    nf = get(ud.s, 'NFFT');
    ov = get(ud.s,'OVER');
    fs = get(ud.w,'Fs');
    dif = round(nf - ov);
    pcg = round((nf - ov) / nf * 100);
    switch dif
        case 0, v = 1
        case fs, v = 6;
        case (fs * 2), v = 7;
        case (fs * 5), v = 8;
        case (fs * 10), v = 9;
        case (fs * 30), v = 10;
        case (fs * 60), v = 11;
        otherwise
            v = 0;
    end
    switch pcg
        case 20, v = 2;
        case 50, v = 3;
        case 80, v = 4;
        case 90, v = 5;
    end
    v
    set(handles.popupmenu_OVER,'value',v);


    %setptr(gcf,P{:}) %set pointer back to normal
end

% UIWAIT makes uispecgram wait for user response (see UIRESUME)
% uiwait(handles.specgramfig);


% --- Outputs from this function are returned to the command line.
function varargout = uispecgram_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes_specgram);
ud = get(handles.specgramfig,'userdata');
v = get(ud.s,'NFFT');
NFFT_sel_index = get(handles.popupmenu_NFFT, 'Value');
switch NFFT_sel_index
    case 7, v= 256;
    case 6, v= 512;
    case 5, v= 1024;
    case 4, v= 2048;
    case 3, v= 4096;
    case 2, v= 8192;
    case 1, v= 16384;
end
ud.s = set(ud.s,'NFFT',v);

ud.s = set(ud.s,'FreqMax',get(handles.slider_FreqMax,'value'));
fs = get(ud.w,'Fs');

switch get(handles.popupmenu_OVER,'value')
    case 1, ov = 0;
    case 2, ov = .20 * v;
    case 3, ov = .50 * v;
    case 4, ov = .80 * v;
    case 5, ov = .90 * v;
    case 6, ov = fs * v;
    case 7, ov = v - (fs * 2);
    case 8, ov = v - (fs * 5);
    case 9, ov = v - (fs * 10);
    case 10, ov = v - (fs * 30);
    case 11, ov = v - (fs * 60);
end

p = getptr(gcf);
setptr(gcf,'watch')

ud.s = set(ud.s,'over',ov);
dbls = [get(handles.minDBLIMS,'value'), get(handles.maxDBLIMS,'value')];
if dbls(1) > dbls(2)
    set(handles.minDBLIMS,'value',dbls(2));
    set(handles.edit_MIN,'value',dbls(2),'string',num2str(dbls(2)));
    set(handles.maxDBLIMS,'value',dbls(1));
    set(handles.edit_MAX,'value',dbls(1),'string',num2str(dbls(1)));
end;
ud.s = set(ud.s,'dblims', sort(dbls));
axes(handles.axes_specgram);
specgram(ud.s,ud.w);
colorbar('horiz');
set(handles.specgramfig,'userdata',ud);

set(gcf,p{:}); %set pointer back to what it was before...

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.specgramfig)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.specgramfig,'Name') '?'],...
    ['Close ' get(handles.specgramfig,'Name') '...'],...
    'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.specgramfig)


% --- Executes during object creation, after setting all properties.
function popupmenu_NFFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

set(hObject, 'String', {'16384', '8192', '4096', '2048', '1024', '512', '256'});

% --- Executes on selection change in popupmenu3.
function popupmenu_NFFT_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3

if get(handles.checkbox_AutoUpdate,'value')
    uispecgram('pushbutton1_Callback',handles.pushbutton1,eventdata,handles)
end

% --- Executes during object creation, after setting all properties.
function minDBLIMS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minDBLIMS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function minDBLIMS_Callback(hObject, eventdata, handles)
% hObject    handle to minDBLIMS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(hObject,'Value',round(get(hObject,'Value')));
set(handles.edit_MIN,'string',num2str(get(hObject,'Value')),'value',get(hObject,'Value'));

if get(handles.checkbox_AutoUpdate,'value')
    uispecgram('pushbutton1_Callback',handles.pushbutton1,eventdata,handles)
end

% --- Executes during object creation, after setting all properties.
function maxDBLIMS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxDBLIMS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function maxDBLIMS_Callback(hObject, eventdata, handles)
% hObject    handle to maxDBLIMS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

set(hObject,'Value',round(get(hObject,'Value')));
set(handles.edit_MAX,'string',num2str(get(hObject,'Value')),'value',get(hObject,'Value'));

if get(handles.checkbox_AutoUpdate,'value')
    uispecgram('pushbutton1_Callback',handles.pushbutton1,eventdata,handles)
end

% --- Executes during object creation, after setting all properties.
function popupmenu_OVER_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_OVER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenu_OVER.
function popupmenu_OVER_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_OVER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_OVER contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_OVER

if get(handles.checkbox_AutoUpdate,'value')
    uispecgram('pushbutton1_Callback',handles.pushbutton1,eventdata,handles)
end

% --- Executes during object creation, after setting all properties.
function edit_MAX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_MAX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit_MAX_Callback(hObject, eventdata, handles)
% hObject    handle to edit_MAX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_MAX as text
%        str2double(get(hObject,'String')) returns contents of edit_MAX as a double


% --- Executes during object creation, after setting all properties.
function edit_MIN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_MIN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit_MIN_Callback(hObject, eventdata, handles)
% hObject    handle to edit_MIN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_MIN as text
%        str2double(get(hObject,'String')) returns contents of edit_MIN as a double


% --- Executes during object creation, after setting all properties.
function slider_FreqMax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_FreqMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function slider_FreqMax_Callback(hObject, eventdata, handles)
% hObject    handle to slider_FreqMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

set(hObject,'Value',round(get(hObject,'Value')));
set(handles.edit_FreqMax,'string',num2str(get(hObject,'Value')),'value',get(hObject,'Value'));

if get(handles.checkbox_AutoUpdate,'value')
    uispecgram('pushbutton1_Callback',handles.pushbutton1,eventdata,handles)
end

% --- Executes during object creation, after setting all properties.
function edit_FreqMax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_FreqMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit_FreqMax_Callback(hObject, eventdata, handles)
% hObject    handle to edit_FreqMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_FreqMax as text
%        str2double(get(hObject,'String')) returns contents of edit_FreqMax as a double


% --- Executes on button press in checkbox_AutoUpdate.
function checkbox_AutoUpdate_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_AutoUpdate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_AutoUpdate


% --------------------------------------------------------------------
function Specgram2_Callback(hObject, eventdata, handles)
% hObject    handle to Specgram2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Generates a specgram2 figure, suitable for printing and more...

h = figure
ud = get(handles.specgramfig,'userdata');
ud.w
ud.s
figure(h);
specgram2(ud.s,ud.w);
drawnow;


% --------------------------------------------------------------------
function menu_waveform_Callback(hObject, eventdata, handles)
% hObject    handle to menu_waveform (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menuitem_changetimes_Callback(hObject, eventdata, handles)
% hObject    handle to menuitem_changetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if ispc
    set(hObject,'enable','off');
    disp('Time change disabled on PC');
    return
end

%get old waveform for defaults...
ud = get(handles.specgramfig,'userdata');
stt = get(ud.w,'start_matlab');
ent = get(ud.w,'end_matlab');

anS = inputdlg('Start time?','Waveform Starting time',1,{[datestr(stt,23) ' ' datestr(stt,13)]});
%Answer = INPUTDLG(Prompt,Title,LineNo,DefAns
anE = inputdlg('End time?','Waveform Ending time',1,{[datestr(ent,23) ' ' datestr(ent,13)]});

neww = waveform(get(ud.w,'Station'),get(ud.w,'Component'),anS{1},anE{1});
if exist('neww','var')
    ud.w = neww;
    set(handles.specgramfig,'userdata',ud);
    p = getptr(gcf);
    setptr(gcf,'watch') % change cursor to watch (courtesy)
    axes(handles.axes_waveform);
    plot(ud.w);
    axis tight
    set(gcf,p{:})
    uispecgram('pushbutton1_Callback',handles.pushbutton1,eventdata,handles) %plot the spectra for the new waveform
end

% --------------------------------------------------------------------
function menuitem_changestation_Callback(hObject, eventdata, handles)
% hObject    handle to menuitem_changestation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if ~ispc
    %get old waveform for defaults...
    ud = get(handles.specgramfig,'userdata');
    st = get(ud.w,'station');
    cm = get(ud.w,'Component');

    vs = getVolcanoList;
    [v,ok] = listdlg('PromptString','Which Volcano?','SelectionMode','single',...
        'ListString',vs,'InitialValue', find(strcmp(ud.v,vs)));
    v = vs{v};
    load(v,'Stations')
    StaList = upper({Stations.name})
    [an, ok] = listdlg('PromptString','Choose your station:','SelectionMode' , 'single' ,...
        'ListString', StaList,'InitialValue',find(strcmp(st,StaList)))
else
    set(hObject,'enable','off');
    disp('Change of station disabled on PC');
    ok = false;
end

if ok
    cm = upper(inputdlg('Component?','Choose Component',1,{cm}));
    an = StaList(an) %get the selected station
    an = deblank(an(end:-1:1)); an = deblank(an(end:-1:1)); %get rid of spaces
    an = an{1}; %grab the string form the cell
    cm{1}
    p = getptr(gcf);
    setptr(gcf,'circle') %readdisk pointer
    ... do something ...
        neww = waveform(an, cm{1}, get(ud.w,'start_matlab'),get(ud.w,'end_matlab'))
    set(gcf,p{:})
    if isa(neww,'waveform')
        ud.w = neww;
        set(handles.specgramfig,'userdata',ud); %make the new waveform available
        setptr(gcf,'watch') % change cursor to watch (courtesy)
        axes(handles.axes_waveform);
        plot(ud.w);
        axis tight
        set(gcf,p{:})
        uispecgram('pushbutton1_Callback',handles.pushbutton1,eventdata,handles) %plot the spectra for the new waveform
    end
end


%%%HELPER FUNCTION %%%
function vnames = getVolcanoList
%uses ICEWEB's list of volcanoes.
if isunix
    pv = dbpf('/home/iceweb/PARAMETER_FILES/volcanoes.pf');
    vnames = pf2struct(pv);
    vnames = vnames.volcanoes; %vnames is now a cell of volcano names
    clear(dbpf);
else
    vnames = {}; %nothing to return
end
