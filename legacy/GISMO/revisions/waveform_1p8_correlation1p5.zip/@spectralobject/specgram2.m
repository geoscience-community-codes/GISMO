function specgram2(s, ws, a)
%SPECGRAM2 - plots spectrogram of waveforms with waveform along top
%
%      USAGE: specgram2(spectralobject, waveform, ax);
% 
%      to clear the figure, use specgram2(spectralobject,waveform,0), otherwise
%      you'll end up nesting spectrograms since I use the current axis.  What
%      works best, though, setting your current axis BEFORE using specgram2.
% 
%      if you want to plot over the same axis, first define your axis, then
%      use a command like axish = get(gca,'position') to keep track of where
%      you are... then you can set your current axis back to axis(axish) 
%      before calling specgram2.
% 
%      ax is either a handle to an axis, or the position of the axis...
% 
%      Default values are NYQ = 50, nfft = 256, over = nfft/2 and 
%      freqmax = NYQ.  If you prefer not to input the specific dB limits,
%      it will scale for you.  
% 
%      The colormap I use is "spectral.map", but can be changed with SETMAP.  
% 
%
%   See also SPECTRALOBJECT/SPECGRAM

% VERSION: 1.0 of spectralobject
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/07/2007



%enforce input arguments.
if ~isa(ws,'waveform')
    error('Second input argument should be a waveform, not a %s',class(ws));
end

%find out area we've got to work in
left=1; bottom=2; width=3; height=4;
clabel= 'Relative Amplitude  (dB)'; 

if exist('a','var')
    if length(a) == 1  %axis handle
        if a == 0, 
            clf;
            pos = get(gca,'position');
        else  
            pos = get(a,'position');
        end
    else %position
        pos = a;
    end
else
    pos = get(gca,'position'); % pos is [left bottom width height]
end
wavepos = [ pos(left), pos(bottom)+pos(height)*0.85,  pos(width) , pos(height) * 0.15] ;
specpos = [ pos(left), pos(bottom), pos(width), pos(height) * 0.85 ];

subplot('position',wavepos);
plot(ws,'xunit',s.scaling);
axis tight;
subplot('position',specpos);
specgram(s,ws);
title('');
colorbar_axis(s,'horiz',clabel)	 