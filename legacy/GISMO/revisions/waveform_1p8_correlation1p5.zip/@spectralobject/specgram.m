function h = specgram(s, ws, alternateMap)
%SPECGRAM - plots spectrogram of waveforms
%   specgram(spectralobject, waveforms)
%   Generates a spectragram from the waveform
%
%   h = specgram(spectralobject, waveforms)
%   Generates a spectragram from the waveform and returns a handle to it
%
%   h = specgram(spectralobject, waveforms, alternateMap);
%   Generates a spectragram from the waveform and uses a specific map
%   
%   The colormap I use is "SPECTRAL_MAP", but can be changed by passing
%   your preferred map as a parameter.  An alternate way of setting the
%   global map is by using the SETMAP function.
%
%
%  See also SPECTRALOBJECT/SPECGRAM2
 
% VERSION: 1.0 of spectralobject
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/7/2007

global SPECTRAL_MAP

%enforce input arguments.
if ~isa(ws,'waveform')
    error('Second input argument should be a waveform, not a %s',class(ws));
end

for j = 1:numel(ws); %added to handle arrays and vectors of waveforms
    if numel(ws) > 1
        subplot(size(ws,1),size(ws,2),j);
    end
    w = ws(j);
    %%  once was function specgram(d, NYQ, nfft, noverlap, freqmax, dBlims)
    
    d = get(w,'data')'; %should be column data already!
    nx = length(d); 
    log = 0; 
    %clabel= 'Relative Amplitude  (dB)'; %%not used outside of specgram2
    
    window = hanning(s.nfft);
    NYQ = get(w,'NYQ');
    Fs = get(w,'Fs');
    nwind = length(window); 
    
    if nx < nwind    % zero-pad x if it has length less than the window length 
        d(nwind) = 0;
        nx=nwind; 
    end 
    d = d(:); % make a column vector for ease later 
    
    ncol = fix( (nx - s.over)/(nwind - s.over) ); 
    
    %added "floor" below
    colindex = 1 + floor(0:(ncol-1))*(nwind- s.over); 
    rowindex = (1:nwind)'; 
    if length(d)<(nwind+colindex(ncol)-1) 
        d(nwind+colindex(ncol)-1) = 0;   % zero-pad x 
    end 
    
    y = zeros(nwind,ncol); 
    
    % put x into columns of y with the proper offset 
    % should be able to do this with fancy indexing! 
    A_ = colindex(  ones(nwind, 1) ,: )    ;
    B_ = rowindex(:, ones(1, ncol)    )    ;
    %C_ = fix(A_ + B_ -1);
    %y(:) = d(C_);
    y(:) = d(fix(A_ + B_ -1));
    clear A_ B_ 
    
    %y(:) = d(fix(rowindex(:,ones(1,ncol))+colindex(ones(nwind,1),:)-1)); 
    
    
    for j = 1:ncol;		%  remove the mean from each column of y
        y(:,j) = y(:,j)-mean(y(:,j));
    end
    
    
    % Apply the window to the array of offset signal segments. 
    y = window(:,ones(1,ncol)).*y; 
    
    % USE FFT 
    % now fft y which does the columns 
    y = fft(y,s.nfft); 
    if ~any(any(imag(d)))    % x purely real 
        if rem(s.nfft,2),    % nfft odd 
            select = 1:(s.nfft+1)/2; 
        else 
            select = 1:s.nfft/2+1; 
        end 
        y = y(select,:); 
    else 
        select = 1:s.nfft; 
    end 
    f = (select - 1)'*Fs/s.nfft; 
    
    t = (colindex-1)'/Fs; 
    
    
    NF = s.nfft/2+1; 
    nf1=round(f(1)/NYQ*NF);                     %frequency window 
    if nf1==0, nf1=1; end	 
    nf2=NF; 
    
    y = 20*log10(abs(y(nf1:nf2,:))); 
    
    F = f(f <= s.freqmax);
    
    
    if F(1)==0, 
        F(1)=0.001;
    end 
    
    h = imagesc(t,F,y(nf1:length(F),:),s.dBlims);  
    %       colorbar_axis(dBlims,'horiz',clabel)
    titlename = [get(w,'Station') '-' get(w,'component') '  from:' get(w,'start_Str')];
    title (titlename);
    axis xy;   
    
    if exist('alternateMap','var')
        colormap(alternateMap);
    else
        colormap(SPECTRAL_MAP);
    end
    
    
    shading flat 
    if log, set(gca, 'yscale', 'log'), end 
    
    ylabel ('Frequency (Hz)') 
    xlabel('Time (s)')
    
    %colorbar_axis(dBlims,'horiz',clabel)	 
end;