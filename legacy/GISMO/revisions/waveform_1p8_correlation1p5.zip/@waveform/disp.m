function disp(w)
%DISP Waveform disp overloaded operator


% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/6/2007

if numel(w) > 1;
    disp(' ');
    disp(sprintf('[%s] %s object with fields:',...
        size2str(size(w)), class(w)));
    disp('     station');
    disp('     channel');
    disp('     start');
    disp('     freq');
    disp('     data');
    disp('     units');
    
    % handle miscelleneous fields
    a = w(1).misc_fields; 
    for n=2:length(w); 
        a = intersect(a,w(n).misc_fields);
    end
    if isempty(a) %no fields in common
        if ~isempty([w.misc_fields])
            % no fields in common, but fields exist
            disp('    With dissimilar fields');
        end
    else
        disp('   with common fields...')
        disp(a')
    end
        

else
    disp(['   station: ' w.station]);
    disp(['   channel: ' w.channel]);
    disp(['     start: ' get(w,'start_str')]);
    disp(['            duration(' , get(w,'duration_str'), ')']);
    disp(['      data: ' num2str(length(w.data)) ' samples']);
    disp(['      freq: ' num2str(get(w,'Fs')) ' Hz']);
    disp(['     units: ' w.units]);
    if numel(w.misc_fields) > 0,
        disp('    With misc fields...');
    end;
    for n= w.misc_fields
        val = get(w,n{1}); %grab value associated with this misc_field
        displayIF = (isnumeric(val) || islogical(val)) && (numel(val)<=6);
        displayIF = displayIF || ischar(val);

        if ~displayIF
            %must be some sort of object or multiple-value field
            fprintf('    * %s: ',n{1});
            fprintf('[%s] %s object\n',...
                size2str(size(val)), class(val) );
        else            
            fprintf('    * %s: ',n{1});
            if ischar(val)
                fprintf('%s',val);
            else
                fprintf('%s',num2str(val));
            end
            fprintf('\n');
        end

    end
end;

function DispStr = size2str(sizeval)    
% helper function that changes the way we view the size
%   from : [1 43 2 6] (numeric)  to  '1x43x2x6' (char)

    DispStr = sprintf('x%d', sizeval);
    DispStr = DispStr(2:end);
