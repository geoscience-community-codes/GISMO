function w = demean (w)
%DEMEAN remove offset voltage from signal
%   waveform = demean(waveform)
%   Removes the mean signal from the waveform object
%
%   Input Arguments
%       WAVEFORM: a waveform object   N-DIMENSIONAL

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/6/2007

Nmax = numel(w);

for I = 1 : Nmax
    w(I) = w(I) - mean(w(I));
end

w = addHistory(w,'mean removed');