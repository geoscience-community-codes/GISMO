function w = set(w, varargin)
%SET Set properties for waveform object(s)
%   w = Set(w,prop_name, val, [prop_name, val])
%   SET is one of the two gateway functions of an object, such as waveform.
%   Properties that are changed through SET are typechecked and otherwise
%   scrutinized before being stored within the waveform object.  This
%   ensures that the other waveform methods are all retrieving valid data,
%   thereby increasing the reliability of the code.
%
%   Another strong advantage to using SET and GET to change  and retrieve
%   properties, rather than just assigning them to the waveform directly,
%   is that the underlying data structure can change and grow without
%   harming the code that is written based on the waveform object.
%
%   Valid property names:
%
%       STATION, CHANNEL, FREQ, DATA, UNITS: self explanatory
%       START :         Set the start-time using matlab format or string
%       START_EPOCH:    Set the start-time using epoch (antelope) time
%       SAMPLE_LENGTH : adjusts the length of the data to length VAL.
%                       If this number is shorter than existing data, SET
%                       truncates after sample VAL.  If it is longer, then
%                       SET will pad the end with zeroes to get length VAL.
%
%       If user-defined fields were added to the waveform (ie, through
%       addField), these fieldnames are also available through set.
%
%       for example
%           % create a waveform object, and add a field called DUMMY with
%           % the value 12
%           w = addfield(waveform,'DUMMY',12);
%
%           % change the value of the DUMMY field
%           w = set(w,'DUMMY',32);
%
%           % change the station and channel at once
%           w = set(w,'Station','YCK', 'Channel', 'BHZ');
%
%   Batch changes can be made if input w is a matrix (use with care!)
%
%   NOTE: There is no set support for "version".  This is handled entirely
%         within the waveform constructor and the loadobj function.
%
%
%  See also WAVEFORM/GET

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/15/2007

global dep2mep

Vidx = 1 : numel(varargin);

while numel(Vidx) >= 2
    prop_name = varargin{Vidx(1)};
    val = varargin{Vidx(2)};

    for n = 1 : numel(w);
        out = w(n);

        switch upper(prop_name)
            case 'STATION'
                if ~isa(val,'char')
                    Error('Station should be a string not a %s', class(val));
                end
                out.station = val;


            case {'COMPONENT','CHANNEL'}
                if ~isa(val,'char')
                    Error('Component should be a string not a %s', class(val));
                end
                out.channel = val;


                if strcmpi(prop_name,'COMPONENT')
                    warning('Waveform:PreferChannel',...
                        ['Please use ''channel'' instead of ''component'''...
                        '  no harm, no foul']);
                end

            case {'FS', 'FREQ'}
                if ~isnumeric(val)
                    error('Frequency should be numeric, not %s', class(val));
                end
                out.Fs = val(1);


            case {'START', 'START_MATLAB'}
                %AUTOMATICALLY figures out whether date is antelope or matlab
                %format
                if ~(isnumeric(val) || isa(val,'char'))
                    error('Start time not assigned... Unknown value');
                end
                out.start = datenum(val);



            case {'START_ANTELOPE', 'START_EPOCH'}
                if ~isnumeric(val),
                    error('Epoch time should be numeric, not %s', class(val));
                end
                out.start = datenum(dep2mep(val));

            case 'DATA'
                if ~isnumeric(val)
                    error('DATA should be numeric, not %s', class(val));
                end
                out.data = reshape(val,length(val),1); %always in a column

            case 'UNITS'
                if ~ischar(val)
                    error('UNITS should be a string, not %s',class(val));
                end
                out.units = val;


            case 'SAMPLE_LENGTH' % chop data or zero pad to specific length
                if ~isnumeric(val),
                    error('SAMPLE_LENGTH should be numeric, not %s',class(val));
                end


                if numel(out.data) >= val
                    out.data = out.data(1:val,1);  % shrink the data
                else
                    out.data(numel(out.data)+1 :val , 1) = 0; %zero pad
                end

            case out.misc_fields
                % One of the user-defined fields has been chosen
                mask = ismember(out.misc_fields, upper(prop_name));
                out.misc_values(mask) = {val};

            otherwise
                error(['can''t understand property name : ', prop_name] );
        end;

        if ~strcmpi(prop_name,{'HISTORY', 'DATA'})
            out = addHistory(out,['Set ' upper(prop_name)]);
        end

        w(n) = out; %put the changed waveform back

    end;

    Vidx(1:2) = []; %done with those parameters, move to the next ones...

end;