function y = mean(w)
%MEAN Average or mean value of waveform's data.
%   Y = mean(waveform)
%   returns a scalar containing the mean value of the waveform data
%
%   Input Arguments
%       WAVEFORM: waveform object   N-DIMENSIONAL
%
%   Output
%       Y: array of same size as WAVEFORM, with each element corresponding
%          to the mean value of the matching waveform 
%

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/6/2007

y = nan(size(w));
for I = 1 : numel(w);
    if ~isempty(w(I))
        y(I) = mean( get(w(I),'data') );
    end
end
