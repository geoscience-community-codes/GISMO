function [whichDirec, whichFile] = which_archive(w)
%WHICH_ARCHIVE return directory and filename of database
%   [whichDirec whichFile] = which_archive(waveform)
%
%   Input Arguments
%       waveform: waveform object
%
%   Output Arguments
%       whichDirec : directory where archive wfdisk file can be found
%       whichFile : actual filename of the database file
%
%  This is the function that needs to be modified when changes to the
%  database locations occur.  Also, this function can be modified to suit
%  your own database purposes.

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/15/2007

% According to Email from mike west 2/2/2007
% all accessable by /iwrun/op/db/archive/archive_YYYY/archive_YYYY_MM_DD

myday = fix(get(w,'start'));

[yr, mo, da, hr, mi, se] = datevec(myday);

%basic location of all archives
base_dir = '/iwrun/op/db/archive/';

% additional directory sometimes used...
archive_dir = sprintf('archive_%04d/', yr);

if myday > now
    %oops... asked for a future date
    warning('Waveform:FutureDate',...
        'Asked for a future date: %s.', get(w,'start_str'));
    whichDirec = '';
    whichFile = '';
    return
end
whichFile = sprintf('archive_%04d_%02d_%02d',yr,mo,da);
whichDirec = [base_dir, archive_dir];

