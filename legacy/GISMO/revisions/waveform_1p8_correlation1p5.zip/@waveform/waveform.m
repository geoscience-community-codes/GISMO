function w = waveform(varargin)
%WAVEFORM Waveform Class constructor
%   w = WAVEFORM() creates a default waveform out of thin air
%
%   w = WAVEFORM(wave) creates a waveform from another one.  This is
%       invoked whenver you create a waveform from another, as in
%           Waveform1 = Waveform2
%
%   w = WAVEFORM(station, channel, freq, start, data)
%          manually puts together a waveform object from the minimum
%          required fields.
%
%    w = WAVEFORM(station, channel, start, end, [alternate directory])
%          loads waveform from a database
%
%    w = WAVEFORM(station, channel, start, end, netwk, loc, server, port)
%          loads from the winston server.  Restrictions apply, see below.
%
%      WAVE - an existing waveform object
%      DATA - a vector of seismic data               (default [])
%      STATION - which seismic station, like 'OKCF'  (default 'UNK')
%      CHANNEL - 'BHZ', 'SHZ', and the like          (default 'EHZ')
%      FREQ - Sampling frequency, in Hz              (default 100)
%      START - Start time, in any format             (default '1/1/1970')
%      END - end time, in any format
%      NETWK - the (two letter) network code         (default 'AV')
%      LOC(ATION) - unused, included for compatability (default '--')
%      SERVER - The Winston wave server     (default 'pubavo1.wr.usgs.gov')
%      PORT   - Port required for the server   (default 16022)
%
%      When Loading data from antelope or winston, the data will be
%      demeaned.
%
%    ---------- USING WAVEFORM WITH WINSTON -------------
%    To use the waveform files with winston, you need to have the usgs.jar
%    file.
%
%    If you have already installed SWARM, then these .jar files already
%    exist in your swarm/lib directory (or something close to it...).
%
%    Edit Matlab's classpath.txt file (located in the toolbox/local
%    directory) and add the location of these four .jar files.
%
%    Input variables for the Winston option include:
%
%      Example of the typical call to Winston...
%       w = waveform('OKCF','EHZ', '10/5/2007 03:15:00','10/5/2007 03:25:00','AV', [], [], []);
%
%       I realize that this may seem bulky, but this is to ensure full function
%       and compatability down the road.  As usual, I make no promises...
%
%    WINSTON WARNING: Currently, data received through winston is not adjusted
%    for instrument gain, therefore, it is in COUNTS.  To fix this, you'll
%    need to multiply it by the correct gain.  Ex.  W = W .* 6.67;  This
%    merely scales the data...
%
%    ------------------------------------------------------
%
%    Additional usage examples (you might not have thought you could...):
%    Use a reference date, such as 'now'
%       w = waveform('GANO','SHZ', fix(now) - 5, fix(now) - 4.875)
%           grabs a three hour waveform from antelope starting 5 days ago
%
%    grab a bunch of stations...
%       snam = [{'TANO'},{'AUL'},{'OKCF'}];
%       for n = 1 : numel(snam)
%         w(n) = waveform(snam{n},'SHZ','3-OCT-2005 04:01','10/3 04:20:12')
%       end;
%
%    For more detail on Winston, contact Peter or Dan Cervelli.

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 6/25/2007


load_global_namespace;

global THIS_VERSION mep2dep dep2mep;

THIS_VERSION = 1.0;
DEFAULT_UNIT = 'Counts';
DEFAULT_FREQ = 100.0;
DEFAULT_CHAN = 'EHZ';
DEFAULT_STATION = 'UNK';
DEFAULT_START = datenum('1/1/1970');
DEFAULT_END = DEFAULT_START + datenum(0,0,0,0,5,0); %five minutes

% the following are for WINSTON access...
DEFAULT_NETWORK = 'AV';
DEFAULT_LOCATION = '--';
DEFAULT_SERVER = 'pubavo1.wr.usgs.gov';
DEFAULT_PORT = 16022;
switch nargin
    case 0
        %create a fresh waveform.  All calls to the waveform object, aside
        %from the "copy" call (case nargin==1) will be initated HERE.
        %Thereafter, the waveform will be modified by set/get.

        w.station = DEFAULT_STATION;
        w.channel = DEFAULT_CHAN;
        w.Fs = DEFAULT_FREQ;
        w.start = datenum('1/1/1970');
        w.data = double([]);
        w.units = DEFAULT_UNIT; %units for data (nm? counts?)
        w.version = THIS_VERSION; %version of waveform object (internal)
        w.misc_fields = {}; %add'l fields, such as "comments", or "trig"
        w.misc_values = {}; %values for these fields
        w = class(w, 'waveform');

        w = addHistory(w,'CREATED');

    case 1

        %"copy" a waveform object

        anyV = varargin{1};
        if isa(anyV, 'waveform')
            % INPUT: waveform (station)
            w = anyV;
        end;

    case 4

        % INPUT: waveform (station, channel, starttime, endtime)

        %sta = varargin{1};
        %chan = varargin{2};
        %Tstart = datenum(varargin{3});
        %Tend = datenum(varargin{4});
        %w = load_waveform(waveform(sta, chan, 100, Tstart, []), Tend);

        %changing to get-set notation.  Single gateway provides more secure
        %data typing
        w = set(waveform,...
            'station',varargin{1},...
            'channel',varargin{2},...
            'Freq',DEFAULT_FREQ,...
            'start',varargin{3});
        w = load_waveform(w, datenum(varargin{4}));
        w = addHistory( set(w,'history',{}) ,'CREATED');

    case 5
        if ischar(varargin{5})

            % INPUT: waveform (station, channel, starttime, endtime, alternatedirectory)

            %    sta = varargin{1};
            %    chan = varargin{2};
            %    Tstart = datenum(varargin{3});
            %    Tend = datenum(varargin{4});
            %    w = load_waveform(waveform(sta, chan, 100, Tstart, []), Tend,varargin{5});
            w = set(waveform,...
                'station',  varargin{1},...
                'channel',varargin{2},...
                'Freq',     DEFAULT_FREQ,...
                'start',    varargin{3});
            w = load_waveform(w, datenum(varargin{4}), varargin{5});
            w = addHistory(set(w,'history',{}),'CREATED');
        else
            % Building a waveform from input pieces
            % INPUT: waveform (station, channel, frequency, starttime,
            % data)

            w = set(waveform,...
                'station',  varargin{1},...
                'channel',varargin{2},...
                'Freq',     varargin{3},...
                'start',    varargin{4},...
                'data',     varargin{5});
            w = addHistory(set(w,'history',{}),'CREATED');
        end;
    case 8
        % INPUT: waveform (station, channel, start, end, network,
        %                  location, server, port)
        MyDefaults = {DEFAULT_STATION, DEFAULT_CHAN, DEFAULT_START, ...
            DEFAULT_END, DEFAULT_NETWORK, DEFAULT_LOCATION,...
            DEFAULT_SERVER, DEFAULT_PORT};
        
        MyVars = {'station', 'channel', 'Tstart', 'Tend', 'network', ...
            'location', 'server', 'port'};
        
        %Fill in all the variables with the appropriate default values
        for N = 1:nargin
            if isempty(varargin{N}),
                eval([MyVars{N},' = MyDefaults{N};'])
            else
                eval([MyVars{N},' = varargin{N};'])
            end
        end
        
        %create the basic waveform with given data
        w = set(waveform,'station',station,...
            'channel',channel, ...
            'start' , Tstart);

        try
            WWS=gov.usgs.winston.server.WWSClient(server,port);
        catch
            %oops, winston's jar files may not exist on this system
            jcp = javaclasspath('-all');
            RequiredFiles = {'usgs.jar'};
            introuble = false;
            for FN = RequiredFiles
                if isempty(strfind([jcp{:}],FN{1}))
                    disp(['Missing ' FN{1}]);
                    introuble = true;
                end
            end
            if introuble
                warning('The winston files may not be on this system.')
                disp('To correct, acquire the files listed above');
                disp('If you have already installed SWARM, then these .jar files already');
                disp('exist in your swarm/lib directory (or something close to it...');
                disp('');
                %disp('Edit Matlab''s classpath.txt file (located in the toolbox/local');
                %disp('directory) and add the location of these .jar files.');

                return

            end
        end

        t1 = mep2dep(datenum(Tstart));
        t2 = mep2dep(datenum(Tend));

        %error check for times t1 & t2
        if t1 > t2, error('Start Time > End Time');  end

        %w = waveform; %create the generic waveform
        
        %grab the winston data, then close the database
        try
            %don't know why "eval" works and the line below doesn't...
        eval('d = WWS.getRawData(station,channel,network,location,t1,t2);');
        %d = WWS.getRawData(station, channel, network, location, t1, t2);
        
        WWS.close;
        catch
            warning('Unable to access Winston Wave Server');
            rethrow(lasterror)
            return
        end
        
       % try
            fs=d.getSamplingRate;
       % catch
%             fprintf('Tried to grab: %s, %s, Network:%s, Loc:%s, From:%s to %s\n',...
%                 station, channel, network, location, ...
%                 datestr(Tstart), datestr(Tend));
%             %disp(WWS);
%             warning('Unable to grab information from the Winston server, returning empty waveform object');
%             return
       % end
        disp(['asked for start time: '...
            sprintf('%4g  %2g  %2g  %2g  %2g  %4.2f ',...
            datevec(dep2mep(t1)))]);
        disp(['received  start time: '...
            sprintf('%4g  %2g  %2g  %2g  %2g  %4.2f ',...
            datevec(dep2mep(d.getStartTime)))]);
        %
        start = dep2mep(d.getStartTime);
        d.buffer(d.buffer == intmin('int32')) = 0; %fix odd spikes
        data = double(d.buffer); % d.buffer is int32, and must be converted
        w = set(w,'start', start,'freq',fs,'data',data);
        w = addHistory(set(w,'history',{}),'CREATED');

        clear WWS fs d data start port server network component

    otherwise

        disp('Invalid arguments in waveform constructor:');
        disp(varargin);
        disp('valid ways of calling waveform include: ');
        disp('   w = WAVEFORM() creates a default waveform');
        disp('   w = WAVEFORM(wave) creates a waveform from another one');
        disp('   w = WAVEFORM(station, channel, freq, start, data)');
        disp('   w = WAVEFORM(station, channel, start, end, [alternate_directory])');
        disp('   w = WAVEFORM(station, channel, start, end, netwk, loc, server, port)');
end

%% LOAD waveform's global_namespace
% Moving these functions away from SUITE_STUFF

function load_global_namespace()

persistent WAVEFORM_NAMESPACE

if WAVEFORM_NAMESPACE
    return
else
    WAVEFORM_NAMESPACE = true;
end

GetWinstonWorking;

global WAVEFORM_HISTORY
WAVEFORM_HISTORY = true; %keep track of waveform modifications

%time converter functions
global mep2dep dep2mep
% matlab date (# days since 0 JAN 0000)
mep2dep = inline ('(matepoch - 719529) * 24 * 3600','matepoch');
% antelope epoch( # secs since 1 JAN 1970 )
dep2mep = inline ('(dep / 86400 + 719529)', 'dep');


%default period for envelopes
global DEFAULT_PERIOD
DEFAULT_PERIOD = 10; %seconds

global SECONDS_IN_DAY
SECONDS_IN_DAY = 24 * 60 * 60;

% directories
% global MASTER_STATION_DBASE    % Default location for master station dbase
% 
% if ispc
%     MASTER_STATION_DBASE = '/Seis/databases/stations/master_stations';
% else
%     MASTER_STATION_DBASE = '/Seis/databases/stations/master_stations';
% end


%% Adding the Java path
function GetWinstonWorking

%Check for required jar file for winston
jcp = javaclasspath('-all');
RequiredFiles = {'usgs.jar'};

introuble = false;

for FN = RequiredFiles
    if isempty(strfind([jcp{:}],FN{1}))
        disp(['Missing ' FN{1}]);
        introuble = true;
    end
end

if introuble
    disp('please add the usgs.jar file (from swarm/lib directory) to your javaclasspath');
    disp('ex.  javaaddpath(''/usr/local/swarm/lib/usgs.jar'');');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MODIFY FOLLOWING LINE TO POINT TO YOUR LOCAL Swarm/lib/usgs.jar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    javaaddpath('http://www.avo.alaska.edu/Input/celso/swarmstuff/usgs.jar');
end
