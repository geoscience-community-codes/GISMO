function w = clearHistory(w)
%CLEARHISTORY reset history of a waveform
%   waveform = clearHistory(waveform)
%   clears the history, leaving current date/time. To remove history 
%   altogether, use 'delfield'
%
%   Input Argument
%       WAVEFORM: a waveform object   N-DIMENSIONAL
%
%
%   Control of whether or not history is added automatically lies within
%   the waveform constructor (in a global variable called WAVEFORM_HISTORY)
%
%
% See also WAVEFORM/ADDHISTORY, WAVEFORM/DELFIELD, WAVEFORM/ADDFIELD.

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/6/2007

w = set(w,'HISTORY',{});
w = addHistory(w,'Cleared History');
