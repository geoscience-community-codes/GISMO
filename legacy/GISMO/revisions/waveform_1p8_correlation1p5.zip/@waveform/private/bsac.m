%BSAC   Be SAC 
%    BSAC(waveform) take an array of x-values and y-values
%    and format the arrays in a way that is compatible with
%    the SAC-like routines such as wsac, lh, or ch. 
%
%    Examples:
%
%    To create a square root function in matlab in the arrays
%    xarray and yarray, and then convert the array information
%    into SAC compatible format and ultimately write to a
%    SAC formatted binary file:
%
%    xarray=linspace(0,30,1000);
%    yarray=sqrt(xarray);     
%    root1 = bsac(xarray,yarray);
%    wsac('root1.sac',root1); 
%
%    by Michael Thorne (4/2004)   mthorne@asu.edu
%
%    See also:  RSAC, LH, CH, WSAC 

% VERSION: 1.0 of waveform objects
% MODIFICATIONS: Celso Reyes
% LASTUPDATE: 2/7/2007 

function [w, output] = bsac(w)

global mep2dep
if numel(w) > 1,
    error('can only run BSAC on a single waveform');
end
output(:,1) = mep2dep(get(w,'timevector')); %get seconds
output(:,1) = output(:,1) - min(output(:,1)); %first should be zero!
output(:,2) = get(w,'data');

%this is done because of how program was already written
xinput = output(:,1);

yinput = output(:,2);

h(303) = 77;
h(304) = 73;
h(305) = 75;
h(306) = 69;
output(303:306,3) = h(303:306)';

%set real header variables
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
h(1:70) = -12345;
output(1:70,3) = h(1:70)';

%set required header variables
head = xinput(2) - xinput(1);
output=ch(output,'DELTA',head);
head = xinput(1);
output=ch(output,'B',head);
head = xinput(length(xinput));
output=ch(output,'E',head);
output=ch(output,'DEPMIN',min(yinput));
output=ch(output,'DEPMAX',max(yinput));
output=ch(output,'DEPMEN',mean(yinput));

%set logical and integer header variables:
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
h(71:110) = -12345;
output(71:110,3) = h(71:110)';

%set required header variables
output=ch(output,'NPTS',length(xinput));
head = 1;
output=ch(output,'IFTYPE',head);
output=ch(output,'LEVEN',head);
output=ch(output,'LCALDA',head);
output=ch(output,'LOVROK',head);
head = 6;
output=ch(output,'NVHDR',head);
head = 0;
output=ch(output,'LPSPOL',head);

%set character header variables:
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
h8 = [45 49 50 51 52 53 32 32];
h16 = [45 49 50 51 52 53 32 32 32 32 32 32 32 32 32 32];
output(111:118,3)=h8';
output(119:134,3)=h16';
output(135:142,3)=h8';
output(143:150,3)=h8';
output(151:158,3)=h8';
output(159:166,3)=h8';
output(167:174,3)=h8';
output(175:182,3)=h8';
output(183:190,3)=h8';
output(191:198,3)=h8';
output(199:206,3)=h8';
output(207:214,3)=h8';
output(215:222,3)=h8';
output(223:230,3)=h8';
output(231:238,3)=h8';
output(239:246,3)=h8';
output(247:254,3)=h8';
output(255:262,3)=h8';
output(263:270,3)=h8';
output(271:278,3)=h8';
output(279:286,3)=h8';
output(287:294,3)=h8';
output(295:302,3)=h8';

%% go through all fields and change 'em (if they'll change...)

% check units
switch lower(get(w,'units'))
    case 'nm' %idisp
        IDEP_ref = 6;
    case 'nm / sec' %ivel
        IDEP_ref = 7;
    case 'nm / sec / sec' %iacc
        IDEP_ref = 8;
    case 'volts' %ivolts
        IDEP_ref = 50;
    otherwise %case 5 = iunkn
        IDEP_ref = 5;
end        
w = set(w,'IDEP',IDEP_ref);

% update fields based on the actual station data...
w = set(w,'KSTNM',get(w,'station'));
w = set(w,'KCMPNM', get(w,'channel'));

[Y,M,D,h,m,s] = datevec( get(w,'start') );
JD = datenum(Y,M,D,h,m,s) - datenum(Y-1,12,31,0,0,0);
w = set(w,'NZYEAR',Y);
w = set(w,'NZJDAY',JD);
w = set(w,'NZHOUR',h);
w = set(w,'NZMIN',m);
w = set(w,'NZSEC',fix(s));
w = set(w,'NZMSEC',(s - fix(s)) * 1000);


fieldsToChange = get(w,'misc_fields');
for n=1: numel(fieldsToChange)
    output = ch(output,fieldsToChange{n}, get(w,fieldsToChange{n}));    
end

