function w = load_waveform(w, endtime, alternateDatabase)
% LOAD_WAVEFORM - loads raw data based on a waveform object
%                 instrument calibration is applied!

% [Waveform] = LOAD_WAVEFORM(waveform) - load 30 min of data from
%                                       waveform's starttime
% [Waveform] = LOAD_WAVEFORM(waveform, endtime)
% [Waveform] = LOAD_WAVEFORM(waveform, endtime, alternateDatabase)
%
% Now we have all of the information to go into the database.
% The section that follows looks up the proper station,
% channel, start and end times, and extracts the data vector.

%
% MODIFIED 10/19/2005, no longer storing requested start; using actual
% start from database, instead.

% VERSION: 1.08 of waveform objects
% AUTHOR: Celso Reyes
% LASTUPDATE: 6/22/2007 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global dep2mep
global mep2dep

%% Double check arguments and fill in necessary information...
switch nargin
    case 1  % only argument was a waveform object.
        % Use its start time and grab a half-hour of data
        endtime = get(w,'start_antelope') + 1800; % 1800 seconds = 0.5 hrs
        
        % figure out which archive to use, generating proper database name
        [direc, filename] = which_archive(w);
        v = [direc, filename];

        
    case 2
        % waveform and endtime were both provided.
        % figure out which archive to use, generating proper database name
            [direc, filename] = which_archive(w);
            v = [direc, filename];

    case 3
        % waveform, endtime, and alternate database all provided
        v = alternateDatabase;
    otherwise
        error('Invalid number of arguments');
end


data = [];

%% ensure times are all working out well...
%can accept dates as string, matlab, or antelope time
if isa(endtime,'char')
    endtime = str2epoch(endtime);
elseif isnumeric(endtime)
    if endtime > datenum('1/1/2500') % likely antelope format
        %do nothing, already in proper format most likely
    else %assuming matlab format
        endtime = mep2dep(endtime);
    end
end;

% check to make sure this all makes sense
starttime = get(w,'Start_epoch');
if endtime <= starttime
    warning('load_Wf:InvalidTimes', 'invalid times! %s : %s', ...
        datestr( dep2mep(starttime) ) , datestr(dep2mep(endtime)));
end


%% Open up the database
dbA = dbopen(v, 'r'); % open appropriate database
db = dblookup_table(dbA, 'wfdisc'); % grab table describing data's location

%check to ensure wfdisk table exists and is populated
if dbnrecs(db) == 0, 
    error('Database not found: %s', v); 
end;

%% sift through database, only grabbing specific station, channel, and time

criteria1 = ['sta == "',get(w,'station'),'"']; % ex.  sta =="OKCF"
criteria2 = ['chan == "', get(w,'channel'),'"']; % ex. chan == "BHZ"
criteria3 = sprintf('time >= %12.18f && time <= %12.18f',starttime,endtime)

db = dbsubset(db, criteria1); %grab records relating to specified station

%check to see if records even exist
if dbnrecs(db) == 0
    error(['No records for Station:', get(w,'station')]); 
end;
db = dbsubset(db, criteria2); %grab records relating to specified channel

%check to see if records even exist
if dbnrecs(db) == 0 
    error(['No records for Channel:', get(w,'channel')]); 
end;


db = dbsubset(db, criteria3); %grab records relating to specified channel

%check to see if records even exist
if dbnrecs(db) == 0 
    error('No records for times: %s to %s\n',datestr(dep2mep(starttime)),datestr(dep2mep(endtime))); 
end;
%%
db.record = 1; %set pointer to the first record

            


try
    %suppress errors that might occur.  This may be a bad idea--not sure
  tr = trload_css(db, starttime, endtime);
catch
    disp(lasterr)
end

if ~exist('tr', 'var')
    %failed record load
    w.data = [];
    w.Fs = 1;
    return;
end;

tr.record = 0;

if (dbquery( tr, 'dbRECORD_COUNT' ) >1);
    trsplice(tr, 1);
end

Q = dbquery( tr, 'dbRECORD_COUNT' );

%preallocate Freq
Freq(Q) = 0;
for j = 1:Q
    tr.record = (j-1);
    trapply_calib(tr); % apply the calibration constant
    plot_starttime = dbgetv(tr, 'time'); %grab actual start from db
    if j==1
        w.start = dep2mep(plot_starttime); %synchronize our waveform start
    end;
    a = trextract_data(tr);
    
    % replace gaps with intermediate values
    gaps = find(a > 10e6);
    % gaps = find(a > 10e4); %changed because of broadbands
    if ~isempty(gaps)
        a(gaps)= mean([a(min(gaps)-1) a(max(gaps)+1)]);
    end
    data = [data; a];
    Freq(j) = dbgetv(tr, 'samprate');
end

%dbclose(db);
trdestroy(tr);
clear tr

w = set(w,'Freq', mean(Freq), 'data',data);

%% get calibration and unit information from the master station database
try
    db = dblookup_table(dbA,'calibration'); %go to the calibration table
    db = dbsubset(db,criteria);            %look at only appropriate sta/chan
    [units, ncalib] = dbgetv(db,'units','calib'); %get units and calibration 
    dbclose(db);
catch
    if exist('db','var')
        try
        dbclose(db);
        catch
        end
    end
    units = 'COUNTS';
    ncalib = 1;
end

%kludge for inconsistencies in database
%as of 1/26/2006, only unit values in table are 
% '-', 'A', 'Celsius', 'V', 'mPa', 'nm/s', 'nm/s**2', 'nm/sec','nm/sec**2',
% 'nm/sec/sec', 'percent', 's'

if iscell(units)
    units = units{1}; % instead of units = char(units);
end

switch lower(units)
    case {'nm/sec**2', 'nm/s**2','nm/sec/sec'}
        units = 'nm / sec / sec';
    case {'nm/sec', 'nm/s'}
        units = 'nm / sec ';
end
w = set(w,'units',units);
w = addfield(w,'calib',ncalib);
%w = w .* ncalib;  % calibration applied earlier with trapply_calib
w = addHistory(w,'Calibration (%f) applied', ncalib);
