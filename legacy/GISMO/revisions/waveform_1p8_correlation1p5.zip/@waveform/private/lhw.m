function w = lhw(w,file)
%LHW fill a waveform object from a sac header
%   waveform = lhw(waveform, file)
%    Read or set matlab variables to SAC header variables from
%    SAC files read in to matlab with rsac.m
%
%    Examples:
%
%    To get the entire header back as a structure, use
%
%    w = lhw(waveform, KATH);
%
%    Each field from the header will be a variable within that structure.
%
%    by Michael Thorne (4/2004)  mthorne@asu.edu
%    modified by Celso Reyes (2/2007) creyes@gi.alaska.edu
%
%    See also:  RSAC, CH, BSAC, WSAC

% VERSION: 1.0 of waveform objects
% MODIFICATIONS: Celso Reyes creyes@gi.alaska.edu
% LASTUPDATE: 2/7/2007 

% first test to see if the file is indeed a sacfile
%---------------------------------------------------------------------------
if (file(303,3)~=77 & file(304,3)~=73 & file(305,3)~=75 & file(306,3)~=69)
    error('Specified Variable is not in SAC format ...')
end

h(1:306) = file(1:306,3);


% read real header variables
%---------------------------------------------------------------------------
DELTA = h(1);
DEPMIN = h(2);
DEPMAX = h(3);
SCALE = h(4);
ODELTA = h(5);
B = h(6);
E = h(7);
O = h(8);
A = h(9);
T0 = h(11);
T1 = h(12);
T2 = h(13);
T3 = h(14);
T4 = h(15);
T5 = h(16);
T6 = h(17);
T7 = h(18);
T8 = h(19);
T9 = h(20);
F = h(21);
RESP0 = h(22);
RESP1 = h(23);
RESP2 = h(24);
RESP3 = h(25);
RESP4 = h(26);
RESP5 = h(27);
RESP6 = h(28);
RESP7 = h(29);
RESP8 = h(30);
RESP9 = h(31);
STLA = h(32);
STLO = h(33);
STEL = h(34);
STDP = h(35);
EVLA = h(36);
EVLO = h(37);
EVEL = h(38);
EVDP = h(39);
MAG = h(40);
USER0 = h(41);
USER1 = h(42);
USER2 = h(43);
USER3 = h(44);
USER4 = h(45);
USER5 = h(46);
USER6 = h(47);
USER7 = h(48);
USER8 = h(49);
USER9 = h(50);
DIST = h(51);
AZ = h(52);
BAZ = h(53);
GCARC = h(54);
DEPMEN = h(57);
CMPAZ = h(58);
CMPINC = h(59);
XMINIMUM = h(60);
XMAXIMUM = h(61);
YMINIMUM = h(62);
YMAXIMUM = h(63);

% read integer header variables
%---------------------------------------------------------------------------
NZYEAR = round(h(71));
NZJDAY = round(h(72));
NZHOUR = round(h(73));
NZMIN = round(h(74));
NZSEC = round(h(75));
NZMSEC = round(h(76));
NVHDR = round(h(77));
NORID = round(h(78));
NEVID = round(h(79));
NPTS = round(h(80));
NWFID = round(h(82));
NXSIZE = round(h(83));
NYSIZE = round(h(84));
IFTYPE = round(h(86));
IDEP = round(h(87));
IZTYPE = round(h(88));
IINST = round(h(90));
ISTREG = round(h(91));
IEVREG = round(h(92));
IEVTYP = round(h(93));
IQUAL = round(h(94));
ISYNTH = round(h(95));
IMAGTYP = round(h(96));
IMAGSRC = round(h(97));

%read logical header variables
%---------------------------------------------------------------------------
LEVEN = round(h(106));
LPSPOL = round(h(107));
LOVROK = round(h(108));
LCALDA = round(h(109));

%read character header variables
%---------------------------------------------------------------------------
KSTNM = char(h(111:118));
KEVNM = char(h(119:134));
KHOLE = char(h(135:142));
KO = char(h(143:150));
KA = char(h(151:158));
KT0 = char(h(159:166));
KT1 = char(h(167:174));
KT2 = char(h(175:182));
KT3 = char(h(183:190));
KT4 = char(h(191:198));
KT5 = char(h(199:206));
KT6 = char(h(207:214));
KT7 = char(h(215:222));
KT8 = char(h(223:230));
KT9 = char(h(231:238));
KF = char(h(239:246));
KUSER0 = char(h(247:254));
KUSER1 = char(h(255:262));
KUSER2 = char(h(263:270));
KCMPNM = char(h(271:278));
KNETWK = char(h(279:286));
KDATRD = char(h(287:294));
KINST = char(h(295:302));


w = waveform; %create a brand new waveform
allvars = who; %all generated names will be in capital letters
allvars( ~strcmp(allvars,upper(allvars)) ) = []; %get rid of other variables
for nrecs = 1:numel(allvars)
    assignVariable = sprintf('header_details.%s = %s;',allvars{nrecs},allvars{nrecs});
    eval(assignVariable);
    if ~ischar(header_details.(allvars{nrecs}))
        %test for valid numeric value
        writeIt =  ~(header_details.(allvars{nrecs}) == -12345);
    else
        %test for valid character value
        writeIt = ~(strcmp(header_details.(allvars{nrecs})(1:8), '-12345  '));
    end
    if writeIt
        w = addfield(w,allvars{nrecs},header_details.(allvars{nrecs}));   
    end
end
w = set(w,'station',deblank(KSTNM));
w = set(w,'channel',deblank(KCMPNM));
mydate= datenum(NZYEAR, 0, NZJDAY, NZHOUR, NZMIN, NZSEC + .001 * NZMSEC);
w = set(w,'start',mydate);
w = set(w,'data',file(:,2));
w = set(w,'freq',1 ./ DELTA); %doesn't take into account ODELTA (observed freq)

switch IDEP
    case 6 %idisp
        IDEP_ref = 'nm';
    case 7 %ivel
        IDEP_ref = 'nm / sec';
    case 8 %iacc
        IDEP_ref = 'nm / sec / sec';
    case 50 %ivolts
        IDEP_ref = 'volts';
    otherwise %case 5 = iunkn
        IDEP_ref = 'Counts';
end
        
w = set(w,'units',IDEP_ref);
    
varargout = header_details;
