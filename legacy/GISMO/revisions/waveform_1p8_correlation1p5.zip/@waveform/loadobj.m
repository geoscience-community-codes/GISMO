function b = loadobj(a)
%LOADOBJ updates older versions of waveform class upon loading
% This handles the updated versions and gives a warning if you're trying to
% load a newer version of a waveform object
%
% The newest version of CMO objects (including waveform) can be found at
% /home/celso/CMO
%
% See also WAVEFORM/WAVEFORM

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/6/2007

global THIS_VERSION
if isa(a,'waveform')
    b = a;
else %a is an old version
    %b = waveform; %
    disp(['Upgrading waveform to new version... v' num2str(THIS_VERSION)]);
    fn = fieldnames(a);
    if ~ismember('version',fn)
        %this waveform exists prior to using version numbers, and is a
        %simple waveform
        b = repmat(waveform,size(a)); %create a default waveform array
        for n = 1: numel(b)
            b(n) = waveform(...
                a(n).station,...
                a(n).channel,...
                a(n).Fs,...
                a(n).start,...
                a(n).data);
            addfield(b(n),'units','unknown');
            addfield(b(n),'calib',1)
        end

        b = reshape(b,size(a));
        return
    end % ~ismember
    
    %If we've reached this portion of code, then we're dealing with a
    %modernish waveform, and upgrades can be based upon the version
    
    switch a(1).version
        case 1
            %current itteration, we shouldn't be here...
        otherwise
            error(['Unknown version of waveform object (', ...
                num2str(a(1).version),...
                ').  Perhaps your waveform suite is out of date.',...
                '  This version:', num2str(THIS_VERSION)]);
    end
end
b = addHistory(b,['Updated to version ' num2str(THIS_VERSION)]);