function val = get(w,prop_name)
%GET Get waveform properties
%   val = get(waveform,prop_name)
%
%   Valid property names:
%       STATION, COMPONENT, FREQ, START_STR, END_STR, DATA, NYQ, PERIOD
%     also:
%       START, END : return datenum format (MatLab's format)
%       START_EPOCH, END_EPOCH : return epoch format.
%
%       DATA_LENGTH : return number of elements in data
%
%       The following return time duration of data
%       DURATION_STR :  text format
%       DURATION: matlab (datenum) format
%       DURATION_EPOCH : antelope (epoch) format (just # of seconds)
%
%       TIMEVECTOR : return a vector of same length as data with
%                    matlab-formatted times.
%
%       MISC_FIELDS: gets a list of fields that were added to this waveform
%       UNITS : Find out what units the data is in (ex. counts, nm/s)
%
%   If waveform is N-dimensional, then VAL will be a cell of the same
%   dimensions.  If GET would return single-values for the property, then
%   VAL will be a matrix of type DOUBLE, arranged in the same dimensions.
%
%       If additional fields were added to waveform using ADDFIELD, then
%       values from these can be retrieved using the fieldname
%
%       Example: Create a waveform, add a field, then get the field
%           W = waveform;
%           W = addfield(W,'P-pick', datenum('1/5/2007 02:12:15'));
%           misc = get(W,'MISC_FIELDS'); %returns a cell with 'P-pick'
%           PickTime = get(W,'P-pick'); % (same as) PickTime = get(W,misc);
%           
%
%   See also WAVEFORM/GETM, WAVEFORM/SET, WAVEFORM/ADDFIELD,
%   WAVEFORM/DELFIELD


%     Modified 1/13/2007 - added support for user-defined fields and
%     cleaned up the cell vs double issues for multiple waveforms
%
%     Modified 2/3/2006 - added TimeVector option.
%     Modified 10/20/2005 - dates now include decimal seconds
%       and n-dimensional waveforms.
%
%   Changes 1/12/2007...
%       Added version, misc fields, units
%       Cleaned up so that values returned as double unless lengths likely
%       different, in which case cells are returned.
%       removed: START_ANT, END_ANT, DURATION_ANT, DURATION_MAT,
%       DURATION_MATLAB
%       reversed decision on CHANNEL vs COMPONENT
%       START and END no longer return the string, they return datenum

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 4/4/2007

global mep2dep

val_CELL = cell(size(w));
val = val_CELL;
prop_name = upper(prop_name);

switch upper(prop_name)

    % IDENTIFICATION PROPERTIES
    case 'STATION' %type:CELL
        val = {w.station};

    case {'CHANNEL', 'COMPONENT'} %type:CELL
        val = {w.channel};

    % DATA DESCRIBING PROPERTIES
        
    case {'FS', 'FREQ'} %type:DOUBLE
        val = [w.Fs];

    case 'DATA' %type:DOUBLE
        val = {w.data}; %cells of data values

    case 'NYQ' %type:DOUBLE
        val = [w.Fs] ./ 2;

    case 'PERIOD' %type:DOUBLE
        val = 1 ./ [w.Fs];

    case 'DATA_LENGTH' %type:DOUBLE
        clear val
        for N = 1: numel(w)
            val(N) = numel(w(N).data);
        end
        
    % TIME PROPERTIES

    case {'START_STR'} %type:CELL
        val = stringDate([w.start]);

    case {'START_EPOCH'} %type:DOUBLE
        val = mep2dep([w.start]);

    case {'START_MATLAB', 'START'} %type:DOUBLE
        val = [w.start];

    case {'END_STR'} %type:CELL
        val = stringDate(grabEndTime(w));

    case {'END_EPOCH'} %type:DOUBLE
        val = mep2dep(grabEndTime(w));

    case {'END_MATLAB', 'END'} %type:DOUBLE
        val = grabEndTime(w);

    case {'DURATION_STR'} %type:CELL
        endvec = grabEndTime(w(:)) - [w(:).start];
        for N = 1 : numel(w)
            val(N) = {durationDate(endvec(N))};
        end

    case {'DURATION_EPOCH'} %type:DOUBLE
        val = (grabEndTime(w) - [w.start]) * 86400;
        %epoch time is # of seconds.

    case {'DURATION_MATLAB', 'DURATION'} %type:DOUBLE
        val = grabEndTime(w) - [w.start];

    case {'TIMEVECTOR'} %type:CELL
        for N = 1 : numel(w)
            Xvalues = linspace(get(w(N),'start'),get(w(N),'end'),length(w(N).data)+1);
            val{N} = Xvalues(1:end-1)';
        end
        
    case {'MISC_FIELDS'} %type:CELL
        val = {w.misc_fields};
        
    case {'UNITS'} %type : CELL        
        val = {w.units};
        
    otherwise
        %perhaps we're trying to get at one of the miscelleneous fields?
        for n = 1 : length(w)
            %tf is whether found or not, loc is the position...
            [tf, loc] = ismember(upper(prop_name), upper(w(n).misc_fields));
            if tf
                val{n} = w(n).misc_values{loc};
            else
                warning('Waveform:UnrecognizedProperty',...
                    'Unrecognized property name : %s',  upper(prop_name));
            end
        end
        %check to see if value can be returned as a numeric value instead
        %of cell.  Only if all values are numeric AND scalar
        numberize = true;
        for n=1:numel(val)
            if ~(isnumeric(val{n}) && isscalar(val{n}))
                numberize = false;
                break
            end
        end
        if numberize,
            Z = val;
            val = nan(size(Z));
            for n=1:numel(Z)
                val(n) = Z{n};
            end
        end 
            
end;
val = reshape(val,size(w)); %return values in proper shape
if isscalar(w) && isa(val,'cell')
    val = val{1}; % return the actual value, not a cell array
end;

%%%%%%%%%%%%%%%%
function val = grabEndTime(w)
dlens = get(w,'data_length');
dlens = dlens(:);

myfrq = get(w,'Freq'); 
myfrq = myfrq(:);

seclen = dlens ./ myfrq;

to_add = datenum([zeros(numel(w),5) seclen])';

svals = [w(:).start];
val = svals +  to_add;

%endvec = datevec([w.start]) + [0 0 0 0 0 length(w.data)/w.Fs];
%endvec = datevec([w.start]) + [0 0 0 0 0 get(w,'data_length') ./ get(w,'Freq')];
%val = datenum(endvec);

%%%%%%%%%%%%%%%%
function val = stringDate(myDate)
% myDate
myDate = datenum(myDate); %make a vector
dv = datevec(myDate); % N x 6 of dates
secbit = num2str(dv(:,6),'%05.2f');
val = strcat(datestr(myDate,1), {' '}, datestr(myDate,15), ':',secbit);

%%%%%%%%%%%%%%%%
function val = durationDate(myDate)
myDate = myDate(:);
[yr mo da hr mi se] = datevec(myDate);
val = '';
%if yr, val = [val sprintf('%2d years ',yr)]; end
%if mo, val = [val sprintf('%2d months ',mo)]; end
if (yr+mo+da)>1,
    val = [val sprintf('%4d days ',fix(myDate))]; 
end
val = [val, datestr(myDate,15)];
se = mod(round(se * 1000) / 1000,60); %kludge to handle rounding error!
val = [val sprintf(':%05.2f',se)];

