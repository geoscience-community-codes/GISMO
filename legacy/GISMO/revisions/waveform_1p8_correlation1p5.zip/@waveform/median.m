function y = median(w)
%MEDIAN middlemost value of waveform's sorted data.
%   Y = median(waveform)
%   returns a scalar containing the median value of the waveform data
%
%   Input Arguments
%       WAVEFORM: waveform object   N-DIMENSIONAL
%
%   Output
%       Y: array of same size as WAVEFORM, with each element corresponding
%          to the median value of the matching waveform 
%

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/15/2007

y = zeros(size(w));
for I = 1 : numel(w);
    if isempty(w(I).data)
        warning('Waveform:NoDataFound',...
            'no data in waveform');
    end
    y(I) = median(w(I).data);
end
