function RMS = rms(W)
%RMS root mean square of a waveform
%   RMS = sqrt((sum(signal .^2) / (N-1))

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/6/2007

RMS = zeros(size(W));

for i = 1 : numel(W) %loop through an array of Waveforms
    Signal = get(W(i),'data'); %grab signal
    N = length(Signal); %
    RMS(i) = sqrt( sum(Signal .^ 2) / (N - 1) );
end