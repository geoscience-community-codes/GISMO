function w = detrend (w, varargin)
%DETREND remove linear trend from a waveform
%   waveform = detrend(waveform, [options])
%   removes the linear trend from the waveform object(s).
%
%   Input Arguments
%       WAVEFORM: a waveform object   N-DIMENSIONAL
%       OPTIONS: optional parameters as described in matlab's DETREND
%
%
% See also DETREND for list of options

% VERSION: 1.0 of waveform objects
% AUTHOR: Celso Reyes (celso@gi.alaska.edu)
% LASTUPDATE: 2/6/2007

Nmax = numel(w);
for I = 1 : Nmax
    
    if isempty(w(I)), continue, end
    
    d = get(w(I),'data');
    w(I) = set(w(I),'data',detrend(d,varargin{:}));
end

w = addHistory(w,'trend removed');