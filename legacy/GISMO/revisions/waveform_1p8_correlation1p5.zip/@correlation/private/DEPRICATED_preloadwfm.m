function c = preloadwfm(stat,chan,trig,pretrig,posttrig);

% C = PRELOADWFM('stat','chan',trig,preload,postload)
% This function reads a set of equal length waveforms
% based on an input list of event "trigger" times. The inputs are:
%       stat:           station name
%       chan:           channel name
%       trig:           vector of absolute trigger times
%                         (in matlab serial time format)
%       pre/posttrig:   these times in seconds define the width of the
%                         window for each trace
%
% The output is a matrix of waveform data in which each column is one
% trace. In the case that some waveforms cannot be read successfully, the
% correlation structure will not be the same length as the input list of
% trigger times.


% READ IN WAVEFORM OBJECTS
good = ones(size(trig));
fprintf('Creating matrix of waveforms ...');
for i = 1:length(trig)
    try
        w(i) = waveform(stat,chan,trig(i)-pretrig/86400,trig(i)+posttrig/86400);
        freq(i) = get(w(i),'Fs');
        fprintf('.');
    catch
        disp(' ');
        disp(['* Error loading waveform at ' datestr(trig(i)) '. Trace not loaded.']);
        good(i) = 0;    % mark waveform as empty
    end;
end;
disp(' ');
%
% STORE ONLY GOOD TRACES
w = w(good);
trig = trig(good);
freq = freq(good);
%
% RESAMPLE TRACES TO MAXIMUM FREQUENCY
fmax = round(max(freq))
for i = 1:length(trig)
	if get(w(i),'FREQ') ~= fmax
		w(i) = align(w(i),trig(i),fmax);
		disp(['Trace no. ' num2str(i) ' is being resampled to ' num2str(fmax) ' Hz']);
	end
end
%
% TRIM AND FILL CORRELATION STRUCTURE
c.W = reshape(w,length(w),1);
c.trig = reshape(trig,length(trig),1);
%
% DATA MUST BE CLIPPED TO [PRETRIG POSTTRIG] RANGE ONCE THE CORRELATION OBJECT IS CONSTRUCTED
