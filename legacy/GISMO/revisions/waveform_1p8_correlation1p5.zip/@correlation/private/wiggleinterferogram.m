function wiggleinterferogram(c,scale,type,norm)

% Private method. See ../plot for details.



% EXTRACT IMAGE
w = get(c,'WAVES');
if isempty(get(w(1),'interferogram_time'))
    error('PLOT INTERFER method can only be used following INTERFEROGRAM function');
end    
I.time  = get(w(1),'INTERFEROGRAM_TIME');
I.index = get(w(1),'INTERFEROGRAM_INDEX');
I.CC    = get(w(1),'INTERFEROGRAM_MAXCORR');
I.LL    = get(w(1),'INTERFEROGRAM_LAG');


% PREP PLOT
figure('Color','w','Position',[50 50 850 1100]);
box on; hold on;


% FIX ORDER OF TRACES
ord = 1:get(c,'TRACES');


% GET MEAN TRACE AMPLITUDE FOR SCALING BELOW (when norm = 0)
maxlist = [];
for i = ord
    maxlist(end+1) = max(abs( get(c.W(i),'DATA') ));
end;
normval = mean(maxlist);


% ADD IMAGE
if strncmpi(type,'C',1)
    imagesc(I.time,I.index,I.CC)
    colormap(c,'LTC');
    
elseif strncmpi(type,'L',1)
    h = imagesc(I.time,I.index,I.LL)
    colormap(c,'LAG');
    cmax = 0.03;
    caxis([-cmax cmax]);
else
    error('Plot type not recognized.');
end
colorbar;
hold on;


% LOOP THROUGH WAVEFORMS
tmin =  999999;
tmax = -999999;
count = 0;
for i = ord
	count = count + 1;
    d = get(c.W(i),'DATA');            %%%d = c.w(:,i);
	if norm==0
        d = scale * d/normval;			% do not normalize trace amplitudes
    else
        if max(abs(d))==0
            d = scale * d;              	% ignore zero traces
        else
            d = scale * d/max(abs(d));		% normalize trace amplitudes
        end
    end
    d = -1 * d; 				% because scale is reversed below
	wstartrel = 86400*(get(c.W(i),'START_MATLAB')-c.trig(i));	% relative start time (trigger is at zero)
	tr = wstartrel + [ 0:length(d)-1]'/get(c.W(i),'Fs'); 
	plot(tr,d+count,'k-','LineWidth',2);
    % save min and max relative trace times
	if tr(1) < tmin
		tmin = tr(1);
	end;
	if tr(end) > tmax
		tmax = tr(end);
	end;

end;


% adjust figure
axis([tmin tmax 0 length(ord)+1]);
set(gca,'YDir','reverse');
set(gca,'YTick',1:length(ord));
set(gca,'YTickLabel',datestr(c.trig(ord)),'FontSize',6);
xlabel('Relative Time,(s)','FontSize',8);




% replace dates with station names if stations are different
if ~check(c,'STA')
    sta  = get(c,'STA');
    chan = get(c,'CHAN');
    
    for i=1:get(c,'TRACES')
       labels(i) = strcat( sta(i) , '_' , chan(i) );
    end
    set( gca , 'YTick' , [1:1:get(c,'TRACES')] );
    set( gca , 'YTickLabel' , labels );
end




%PRINT OUT FIGURE
set(gcf, 'paperorientation', 'portrait');
set(gcf, 'paperposition', [.25 .25 8 10.5] );
%print(gcf, '-depsc2', 'FIG_alignwfm.ps')
%!ps2pdf FIG_alignwfm.ps
%!convert FIG_alignwfm.ps FIG_alignwfm.gif
%!rm FIG_alignwfm.ps

