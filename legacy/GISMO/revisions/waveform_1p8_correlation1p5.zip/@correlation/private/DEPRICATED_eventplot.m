%function eventplot(c,scale);
%
% THIS VERSION OF EVENTPLOT PREDATES WAVEFORMS IN CORRELATION
% OBJECT AND STACK FUNCTION
%
% Private method. See ../plot for details.



if ~strcmpi(class(c),'correlation')
    error('First input must be a correlation object');
end;

if isempty(get(c,'LINK'))
    error('LINK field must be filled in input object');
end;

if isempty(get(c,'CORR'))
    error('CORR field must be filled in input object');
end;

if isempty(get(c,'CLUST'))
    error('CLUST field must be filled in input object');
end;

if ~isempty(get(c,'LAG'))
    warning('Time corrections from LAG field have not been applied to traces. ADJUSTTRIG may be necessary');
end;




% GET TIME MAX AND MINS
tmin = 0;
tmax = 0;
count = 0;
for i = 1:length(c.trig)
	wstartrel = 86400*(c.start(i)-c.trig(i));	% relative start time (trigger is at zero)
        tr = wstartrel + [ 0:size(c.w,1)-1]'/c.Fs; 

    % save min and max relative trace times
	if tr(1) < tmin
		tmin = tr(1);
	end;
	if tr(end) > tmax
		tmax = tr(end);
	end;
end;


% MAKE ALIGNED DATA MATRIX
% Similar shadedplot.m except traces arein order defined by trig.
disp('Warning: events are only aligned to the nearest sample before stacking');
p = 1/c.Fs;         % sampling period
tmin = round(tmin*c.Fs)*p;      % round to nearest sample
tmax = round(tmax*c.Fs)*p;
N = 1:length(c.trig);
T = [ tmin : p : tmax ];
D = zeros(length(N),length(T));
count = 0;
for i = 1:length(c.trig)
	count = count + 1;
	d = c.w(:,i)';
	d = scale * d/max(abs(d));		% apply a uniform amplitude scale;
	wstartrel = 86400*(c.start(i)-c.trig(i));	% relative start time (trigger is at zero)
       [tmp,startindex] = min(abs(T-wstartrel));
        D(count,startindex:startindex+size(c.w,1)-1) = d; 
end;



% PREP PLOT
figure('Color','w','Position',[50 50 680 880]);
subplot(2,1,2);
box on; hold on;


% DEFINE SIGNIFICANT CLUSTERS
tmp = [];                   % number of traces in each cluster
for i = 1:max(c.clust)
     tmp(i) = sum(c.clust==i);
end
dolist = find(tmp>8);       % Select which clusters to process


% LOOP THROUGH CLUSTERS / PLOT EVENTS / STACK TRACES
Ds = [];
count = 0;
cols = ['m' ; 'g' ; 'k' ; 'r' ; 'b'];
for i = dolist
    count = count + 1;
    tn = find(c.clust==i);        % find trace numbers
    plot(c.trig(tn),count*ones(size(tn)),'o','Color',cols(count));

    % stack traces
    Ds(count,:) = sum(D(tn,:))./length(tn);
    

end;


datetick('x');
axis([min(c.trig) max(c.trig) 0 count+1]);



% PLOT STACKS
subplot(2,1,1);
box on; hold on;
[n1,n2] = size(Ds);
for i = 1:n1
    plot(T,Ds(i,:)+i,'-','Color',cols(i));
end;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % GET TIME MAX AND MINS
% tmin = 0;
% tmax = 0;
% count = 0;
% for i = ord
% 	wstartrel = 86400*(c.start(i)-c.trig(i));	% relative start time (trigger is at zero)
%         tr = wstartrel + [ 0:size(c.w,1)-1]'/c.Fs; 
% 
%     % save min and max relative trace times
% 	if tr(1) < tmin
% 		tmin = tr(1);
% 	end;
% 	if tr(end) > tmax
% 		tmax = tr(end);
% 	end;
% end;
% 
% 
% % MAKE IMAGE MATRIX
% p = 1/c.Fs;         % sampling period
% tmin = round(tmin*c.Fs)*p;      % round to nearest sample
% tmax = round(tmax*c.Fs)*p;
% N = 1:length(ord);
% T = [ tmin : p : tmax ];
% D = zeros(length(N),length(T));
% count = 0;
% for i = ord
% 	count = count + 1;
% 	d = c.w(:,i)';
% 	d = scale * d/max(abs(d));		% apply a uniform amplitude scale;
% 	wstartrel = 86400*(c.start(i)-c.trig(i));	% relative start time (trigger is at zero)
%        [tmp,startindex] = min(abs(T-wstartrel));
%         D(count,startindex:startindex+size(c.w,1)-1) = d; 
% end;
% imagesc(T,N,D);
% 
% 
% % ADJUST PLOT
% axis([tmin tmax 0.5 length(ord)+0.5]);
% set(gca,'YDir','reverse');
% n = length(ord);
% set(gca,'YTick',[1:round(n/50):n]);
% yt = get(gca,'YTick');
% set(gca,'YTickLabel',datestr(c.trig(ord(yt))),'FontSize',6);
% xlabel('Relative Time,(s)','FontSize',8);
% 
% 
% % SET COLOR MAP
% cmap = [ 0 0 1;
%           1 1 1
%           1 0 0];
% cmap = interp1([-1 0 1],cmap,[-1:.1:1],'linear');
% colormap(cmap);
% 
% 
% %PRINT OUT FIGURE
% set(gcf, 'paperorientation', 'portrait');
% set(gcf, 'paperposition', [.25 .25 8 10.5] );
% print(gcf, '-depsc2', 'FIG_alignwfm.ps')
% %!ps2pdf FIG_alignwfm.ps
% %!convert FIG_alignwfm.ps FIG_alignwfm.gif
% %!rm FIG_alignwfm.ps
% 
