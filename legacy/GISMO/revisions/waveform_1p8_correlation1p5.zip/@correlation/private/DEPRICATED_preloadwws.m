function c = preloadwws(stat,chan,trig,pretrig,posttrig,netwk,loc,server,port);

% C = PRELOADWWS('stat','chan',trig,pretrig,posttrig,'netwk','loc','server',port)
%
% Same as preloadwfm except reads from a Winston server


whos
disp(loc);
disp(server);
disp(port);


% READ IN WAVEFORM OBJECTS 
good = ones(size(trig));
fprintf('Creating matrix of waveforms ...');
for i = 1:length(trig)
    try
        %w(i) = waveform(stat,chan,trig(i)-pretrig/86400,trig(i)+posttrig/86400,'AV','--','pubavo1.wr.usgs.gov',16022);
        w(i) = waveform(stat,chan,trig(i)-pretrig/86400,trig(i)+posttrig/86400,netwk,loc,server,port);
        freq(i) = get(w(i),'Fs');
        samples(i) = length(get(w(i),'Data'));
        fprintf('.');
    catch
        disp(' ');
        disp(['* Error loading waveform at ' datestr(trig(i)) '. Trace not loaded.']);
        good(i) = 0;    % mark waveform as empty
    end;
end;
disp(' ');


% RESAMPLE TRACES TO MAXIMUM FREQUENCY
fmax = max(freq);
if ( sum(round(fmax)==round(freq)) ~= length(freq) )
    %disp(['resampling all data to ' num2str(max(freq)) 'Hz']);
    disp(['Data needs to be resampled to equal frequencies']);
    disp(['***Not implimented by default. Use waveform/align function. ****']);
    return;
    % use waveform resampling
end;


% CREATE DATA MATRIX
c.w = zeros(length(samples),sum(good));
count = 0;
for i=find(good)  % do loop backward
    count = count + 1;
    c.w(1:samples(i),count) = get(w(i),'data');
    c.start(count) = datenum(get(w(i),'start'));
    c.trig(count) = trig(i);
end;


% TRIM AND FILL CORRELATION STRUCTURE
tracelength = round(fmax * (posttrig+pretrig));
c.w = c.w(1:tracelength,:);
c.Fs = round(fmax);
c.start = c.start';
c.trig = c.trig';





