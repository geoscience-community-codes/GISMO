function c = correlation(varargin);

%
% --------- DOCUMENTATION ------------------------------------------------
% | CORRELATION('COOKBOOK') View html-format correlation demo cookbook.  |
% | CORRELATION('README') View detailed version and install information. |
% |   (see below of description of fields within a correlation object)   |
% ------------------------------------------------------------------------
% 
%
% CORRELATION Correlation class constructor, version 1.3.
%
% C = CORRELATION creates an empty correlation object. For explanation see the 
% description below that follows the usage examples.
%
% C = CORRELATION(WAVEFORM)
% Create a correlation object from an existing waveform object. In a pinch
% this formulation can be used, however, it lacks one critical element.
% Without a trigger time, the correlation object has no information about
% how the traces should be aligned. With clean data this may be remedied
% with the XCORR routine. If possible however, it is better to use one of
% the CORRELATION uses which includes trigger times. In the absence of this
% information, trigger times are arbitrarily assigned to be one quarter of
% the time between the trace start and end times.
% 
% C = CORRELATION(WAVEFORM,TRIG)
% Create a correlation object from an existing waveform object and a column
% vector of trigger times. These times can be in the matlab numeric time
% format (serial day) or a recognized string format (see HELP DATENUM).
% TRIG and WAVEFORM must be of the same length.
%
% CORRELATION('DEMO')
% Opens the demo dataset for correlation. This dataset contains a single
% correlation object of 100 traces. It is the data source for the cookbook
% demos.
%
% C = CORRELATION(N) where N is a single number, creates a correlation
% object with N randomly generated simplistic synthetic traces. At times
% useful for offline testing.
%
% C = CORRELATION(CORAL) where CORAL is a data structure from the CORAL
% seismic package (K. Creager, Univ. of Washington). CORAL is a fairly
% comprehensive seismic data and metadata format. CORRELATION and
% the underlying WAVEFORM suite are not. A CORAL to CORRELATION conversion
% should usually be easy. The other direction may be more challenging as
% most correlation and waveform objects do not contain much of the "header"
% info stored by CORAL. 
%
% C = CORRELATION('stat','chan',trig,pretrig,posttrig,'archive') creates a
% correlation object containing waveforms from an Antelope database. In
% order for this to work, you must have a configured version of the
% Antelope toolbox for Matlab. Trace times based on an input list of
% trigger times and cropped according to the pre/posttrig terms. All traces
% in the resulting correlation object have the same frequency and the same
% number of samples. If partial data is returned from the database request,
% traces are zero-padded accordingly. If a trace has a lower frequency than
% other traces in the object, a warning is issued and the trace is
% resampled to the highest frequency in the set of waveforms. For most uses
% this should be a rare occurance.
%
%The inputs are:
%       stat:           station name
%       chan:           channel name
%       trig:           vector of absolute trigger times
%                         (in matlab serial time format)
%       pre/posttrig:   these times in seconds define the width of the 
%                       window for each trace, where pretrig and posttrig 
%                       are times in seconds relative to the trigger time.
%	archive:            database name and path if it is not in the 
%                       working directory
%
% C = CORRELATION('stat','chan',trig,pretrig,posttrig) same as previous
% but data is drawn from the default Antelope database(s), if configured 
% in waveform.
%
% C = CORRELATION('stat','chan',trig,pretrig,posttrig,'netwk','loc','server',port)
% Same as above except waveform data is loaded from Winston wave server.
% See HELP WAVEFORM for description of netwk, loc, server, port and default
% options. Currently the Java routines for reading from a Winston data base
% can return a time window of data somewhat different than requested. Using
% an AVO Winston we find differences in start times of up to 5 seconds.
% This is best accounted for by asking for a larger window of data than
% needed. It can always be cropped later.
%
%
% -------- DESCRIPTION OF CORRELATION OBJECT ----------
% All calls to correlation return a "correlation object" containing
% the following fields where M is the number of traces:
%    TRIG:     trigger times in matlab serial time (Mx1)
%    WAVES:    vector of waveforms (Mx1)
%    CORR:     max correlation coefficients (MxM, single precision)
%    LAG:      lag times in seconds (MxM, single precision)
%                (Example: If the lag time in position (A,B) is positive,
%                 then similar features on trace A occur later in relative
%                 time than on trace B. To align the traces, the lag time
%                 in (A,B) must be added to the trigger time of A)
%    STAT:     statistics about each trace (Mx? see below)
%    LINK:     defines the cluster tree (Mx3)
%    CLUST:    defines individual clusters(families) of events (Mx1)
% The first two fields define the data traces. The last five fields are
% products derived from these data. (Programming note: Internally, these
% fields are referred to as c.trig, c.W, c.C, c.L, c.stat, c.link, and 
% c.clust, respectively.)
%
% The STAT field contains columns of statistics that can be assigned one 
% per trace. The number of columns may be expanded to accomodate 
% additional parameters. Currently it is 5 columns wide. Column 1 is the 
% mean maximum correlation. Column 2 is the high side rms error (1 sigma) 
% of the mean max correlation. Column 3 is the low side rms error (1 
% sigma) of the mean max correlation. Columns 4 is the unweighted least 
% squares best fit delay time for each trace. Column 5 is the rms error of 
% this delay time. See Vandecar and Crosson (BSSA 1990) and HELP GETSTAT 
% for details of how these statistics are calculated.
%
% ********* DEPRICATED ***********
% C = CORRELATION(TRIG) creates a correlation object with all fields empty
% except for the column vector TRIG containing a list of 'trigger times' in matlab
% serial date format.



% CHECK THAT WAVEFORM OBJECT IS SET UP
if (exist('waveform') ~= 2)
    error('waveform suite must be installed in order to use the correlation toolbox.')
end


switch nargin
    case 0
        % NO DATA
            c.W = [];
            c.trig = [];
            c.C = [];
            c.L = [];
            c.stat = [];
            c.link = [];
            c.clust = [];
            c = class(c,'correlation');
            
     case 1
        % ANOTHER CORRELATION OBJECT
        if isa(varargin{1},'correlation')
            c = varargin{1};
        
        % A CORAL STRUCTURE
        elseif isfield(varargin{1},'data') && isfield(varargin{1},'staCode') && isfield(varargin{1},'staChannel')
            c = convert_coral(varargin{1});
        
        % DEMO DATASET
        elseif isa(varargin{1},'char')
            if strncmpi(varargin{1},'DEM',3)
                load demo_data_100;
            end
            
            % OPEN HTML COOKBOOK
            if strncmpi(varargin{1},'COO',3)
                p = which('correlation/correlation');
                p = p(1:end-13);
                slash = p(end);
                web([p 'html' slash 'correlation_cookbook.html']);
                return
            end
                        
            % OPEN README FILE
            if strncmpi(varargin{1},'REA',3)
                p = which('correlation/correlation');
                p = p(1:end-13);
                slash = p(end);
                web([p 'README.txt']);
                return
            end

        % FROM A WAVEFORM WITHOUT TRIGGERS
        elseif isa(varargin{1},'waveform') 	% & length(varargin{1})>=1
            c.W = varargin{1};
	    c.W = reshape(c.W,length(c.W),1);
            c.trig = get(c.W,'START') + 0.25*(get(c.W,'END')-get(c.W,'START'));
            c.trig = reshape(c.trig,length(c.trig),1);
            c.C = [];
            c.L = [];
            c.stat = [];
            c.link = [];
            c.clust = [];
            c = class(c,'correlation');
            
        % WITH SYNTHETIC DATA
        elseif ( isa(varargin{1},'double') & length(varargin{1})==1 )
            co = makesynthwaves(varargin{1});
            c.W = co.W;
            c.trig = co.trig;
            c.C = [];
            c.L = [];
            c.stat = [];
            c.link = [];
            c.clust = [];
            c = class(c,'correlation');
        else
            error('Invalid call to correlation');
        end;
        
    case 2
        % FROM A WAVEFORM WITH TRIGGERS
        if (isa(varargin{1},'waveform'))
            c.W = varargin{1};
	    c.W = reshape(c.W,length(c.W),1);
            if isa(varargin{2},'double')
                disp('is a double');
                c.trig = varargin{2};
		c.trig = reshape(c.trig,length(c.trig),1);
            elseif isa(varargin{2},'char')
                disp('is a char');
                c.trig = datenum(varargin{2});
            else
               error('Time format nor recognized'); 
            end
            c.C = [];
            c.L = [];
            c.stat = [];
            c.link = [];
            c.clust = [];
            c = class(c,'correlation');
        else
            error('Invalid call to correlation');
        end;
        
    case 5
        % WITH DATA LOADED FROM DEFAULT ANTELOPE ARCHIVE
        stat = varargin{1};
        chan = varargin{2};
        trig = reshape(varargin{3},length(varargin{3}),1);
        pretrig = varargin{4};
        posttrig = varargin{5};
        c = loadfromantelope(stat,chan,trig,pretrig,posttrig,[]);
        c.C = [];
        c.L = [];
        c.stat = [];
        c.link = [];
        c.clust = [];
        c = class(c,'correlation');
	c = verify(c);
	c = crop(c,pretrig,posttrig);
        
    case 6
        % WITH DATA LOADED FROM CUSTOM ANTELOPE ARCHIVE
        stat = varargin{1};
        chan = varargin{2};
        trig = reshape(varargin{3},length(varargin{3}),1);
        pretrig = varargin{4};
        posttrig = varargin{5};
        archive = varargin{6};
        c = loadfromantelope(stat,chan,trig,pretrig,posttrig,archive);
        c.C = [];
        c.L = [];
        c.stat = [];
        c.link = [];
        c.clust = [];
        c = class(c,'correlation');
	c = verify(c);
	c = crop(c,pretrig,posttrig);

    case 9
        % WITH DATA LOADED FROM WINSTON WAVE SERVER
        stat = varargin{1};
        chan = varargin{2};
        trig = reshape(varargin{3},1,length(varargin{3}));
        pretrig = varargin{4};
        posttrig = varargin{5};
        netwk = varargin{6};
        loc = varargin{7};
        server = varargin{8};
        port = varargin{9};
        c = loadfromwinston(stat,chan,trig,pretrig,posttrig,netwk,loc,server,port);
        c.C = [];
        c.L = [];
        c.stat = [];
        c.link = [];
        c.clust = [];
        c = class(c,'correlation');
whos
	c = verify(c);
	c = crop(c,pretrig,posttrig);

    otherwise
        error('Invalid input values to correlation');
end;


% ADJUST DATA LENGTH AND SAMPLE RATE IF NECESSARY
if ~check(c,'FREQ')
    c = align(c);
elseif ~check(c,'SAMP')
    c = verify(c);
end






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOAD WAVEFORM DATA FROM AN ANTELOPE DATABASE 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function c = loadfromantelope(stat,chan,trig,pretrig,posttrig,archive);

% READ IN WAVEFORM OBJECTS
good = ones(size(trig));
fprintf('Creating matrix of waveforms ...');
w = waveform;
for i = 1:length(trig)
    try
	if ~isnan(archive)
        	w(i) = waveform(stat,chan,trig(i)+pretrig/86400,trig(i)+posttrig/86400,archive);
	else
        	w(i) = waveform(stat,chan,trig(i)+pretrig/86400,trig(i)+posttrig/86400);
	end
        freq(i) = get(w(i),'Fs');
        fprintf('.');
    catch
        disp(' ');
        disp([stat '_' chan ' at time ' datestr(trig(i),'mm/dd/yyyy HH:MM:SS.FFF') ' could not be loaded.']);
        good(i) = 0;    % mark waveform as empty
    end;
end;
disp(' ');
%
% CHECK TO SEE IF ANY DATA WAS READ IN
if length(w)==0
	error('This data not is available from the specified database.');
end
%
% STORE ONLY GOOD TRACES
w = w(find(good));
trig = trig(find(good));
freq = freq(find(good));
%
% CORRUPT TRACE LENGTHS (FOR TESTING ONLY!)
%w(15) = set(w(15),'FREQ',80);
%w(5) = extract(w(5), 'INDEX',2,1999)
%
% RESAMPLE TRACES TO MAXIMUM FREQUENCY
% fmax = round(max(freq))
% for i = 1:length(trig)
% 	if get(w(i),'FREQ') ~= fmax
%		w(i) = align(w(i),trig(i),fmax);
%		disp(['Trace no. ' num2str(i) ' is being resampled to ' num2str(fmax) ' Hz']);
%	end
%end
%
% FILL CORRELATION STRUCTURE
c.W = reshape(w,length(w),1);
c.W = demean(c.W);
c.trig = reshape(trig,length(trig),1);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOAD WAVEFORM DATA FROM A WINSTON DATABASE 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function c = loadfromwinston(stat,chan,trig,pretrig,posttrig,netwk,loc,server,port);

% READ IN WAVEFORM OBJECTS
good = ones(size(trig));
fprintf('Creating matrix of waveforms ...');
w = waveform;
for i = 1:length(trig)
    try
       	w(i) = waveform(stat,chan,trig(i)+pretrig/86400,trig(i)+posttrig/86400,netwk,loc,server,port);
        freq(i) = get(w(i),'Fs');
        fprintf('.');
    catch
        disp(' ');
        disp([stat '_' chan ' at time ' datestr(trig(i),'mm/dd/yyyy HH:MM:SS.FFF') ' could not be loaded.']);
        good(i) = 0;    % mark waveform as empty
    end;
end;
disp(' ');
%
% CHECK TO SEE IF ANY DATA WAS READ IN
if length(w)==0
	error('This data not is available from the specified database.');
end
%
% STORE ONLY GOOD TRACES
w = w(find(good));
trig = trig(find(good));
freq = freq(find(good));
%
% CORRUPT TRACE LENGTHS (FOR TESTING ONLY!)
%w(15) = set(w(15),'FREQ',80);
%w(5) = extract(w(5), 'INDEX',2,1999)
%
% RESAMPLE TRACES TO MAXIMUM FREQUENCY
fmax = round(max(freq))
for i = 1:length(trig)
	if get(w(i),'FREQ') ~= fmax
		w(i) = align(w(i),trig(i),fmax);
		disp(['Trace no. ' num2str(i) ' is being resampled to ' num2str(fmax) ' Hz']);
	end
end
%
% FILL CORRELATION STRUCTURE
c.W = reshape(w,length(w),1);
c.W = demean(c.W);
c.trig = reshape(trig,length(trig),1);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CONVERT DATA FROM CORAL STRUCTURE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function c = convert_coral(coral)

w = waveform;
t = zeros(size(coral));
for i = 1:length(coral)
    w(i) = waveform;
    w(i) = set( w(i) , 'Station' , coral(i).staCode );
    w(i) = set( w(i) , 'Channel' , coral(i).staChannel );
    w(i) = set( w(i) , 'Data' , coral(i).data );
    w(i) = set( w(i) , 'Start' , datenum(coral(i).recStartTime') );
    w(i) = set( w(i) , 'FREQ' , 1/coral(i).recSampInt );    
    if ~isempty(coral(i).pPick)
        t(i) = datenum(coral(i).pPick');
    end
end
w = demean(w);

if length(find(t))==length(t)
    c = correlation(w,t);
else
    c = correlation(w);
end
%c.W = reshape(w,length(w),1);


