function c = clip(c,varargin)

error('The CLIP function has been removed from the correlation toolbox and replaced with CROP. Please update your script to use CROP. Note that the meaning of the PRETRIG term has been modified in CROP. To convert codes from CLIP to CROP, PRETRIG should be multipled by -1');



