function [w, outW] = demo_picktremor(w)
%DEMO_PICKTREMOR interactively choose and extract segments of data
% demo_picktremor [entire_wave, tremor_wave] = uipicktremor(entire_wave);
% Displays waveforms one-at-a-time, allows user to choose tremor times, and
% then redisplays them with the tremor bits highlighted.  Afterward, return
% the extracted tremor bits and keep the tremor times within the origninal
% waveform.
%
% entire_wave can be either a single waveform, or multiple waveforms.
%
% CREATED 2/7/2006 for Demonstration purposes
% AUTHOR: Celso Reyes
% For use with waveform suite.

% display waveform.  Choose tremor times (start & end)
for n=1:numel(w)
    %plot each waveform in turn. then get the start and stop times for
    %each piece of tremor 
    plot(w(n),'xunit','date'); %plot it    
    
    %give user instructions on the graph itself... down & dirty way...
    xlabel('Click on START of tremor')
    [xST(n),yST(n)] = ginput(1); %
    %give user instructions on the graph itself... down & dirty way...
    xlabel('Click on END of tremor')
    [xED(n),yED(n)] = ginput(1);
end

% grab all the tremor bits, and put them into a new waveform array, while
% adding the start and end times to the original waveform object

for n=1:numel(w);
    %extract the tremor bits into new waveforms
    outW(n) = extract(w(n),'time',xST(n),xED(n));    
    
    %annotate the original waveform
    w(n) = addfield(w(n),'TremorStart',xST(n));
    w(n) = addfield(w(n),'TremorEnd',xED(n));
end

%We wish to plot all waveforms together and at the same scale.
scalevalue = max(max(double(w))); % find largest Amplitude
wplot = w ./ scalevalue;          % now, the largest amplitude is 1.

extractedW = outW ./ scalevalue;  % do the same for the extracted wave.
                                  % however, don't change the original 
                                  % waveform's scale. 


% offset all the waveforms so they'll plot nicely together
for n=1:numel(w);
    wplot(n) = wplot(n) - n; 
    extractedW(n) = extractedW(n) - n;
end

%plot the waveform in black, with xunits of "date".  If another xunit is
%specified, then ALL waveforms will start at time = 0.
plot(wplot,'color','k','xunit','date');

% show a legend for all stations.  This makes more sense when the waveforms
% are plotted in different colors.
legend(get(wplot,'station'));

% plot the tremor bits in RED over the existing plot.
hold on
plot(extractedW,'color','r','xunit','date','linewidth',5);
hold off

%annotate the extracted waveforms with what's happened to 'em.
outW = addHistory(outW,'times grabbed using "testme"');
