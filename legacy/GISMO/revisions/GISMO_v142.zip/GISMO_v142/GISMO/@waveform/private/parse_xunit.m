function [unitName, secondMultiplier] = parse_xunit(unitName)
% PARSE_XUNIT returns a labelname and a multiplier for an incoming xunit
% value.  This routine was removed to centralize this function

