function obj = void_interpreter(filelist)
obj = [];
error('No interpreter has been assigned to this datasource object');